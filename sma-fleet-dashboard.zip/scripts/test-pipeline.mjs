import { getDashboardData } from "../lib/pipeline.mjs";

const data = await getDashboardData({ month: "ก.ค. 69" });
console.log("month:", data.month, "| dashboard updatedAt:", data.dashboardMeta[data.month]?.updatedAt);
console.log("KPIs:", data.kpis);
console.log("\nTeam rows:");
for (const r of data.teamRows) {
  console.log(
    r.team.padEnd(6),
    (r.nickname || "-").padEnd(8),
    "gps=" + String(r.gpsKm).padEnd(8),
    "kiss=" + String(r.kissflowKm).padEnd(8),
    "ratio=" + String(r.ratioPct).padEnd(6),
    "missing=" + String(r.missingDaysThisMonth).padEnd(4),
    "cost=" + String(r.costImpact).padEnd(10),
    "dates=" + JSON.stringify(r.missingDates)
  );
}
console.log("\nTrend:", data.trend);
console.log("\nAfter-hours ranking (top 5):", data.afterHoursRanking.slice(0, 5));
console.log("\nAfter-hours event count this month:", data.afterHoursEvents.length);
