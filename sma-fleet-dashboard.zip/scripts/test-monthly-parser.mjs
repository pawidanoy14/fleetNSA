import fs from "node:fs";
import Papa from "papaparse";
import { parseMonthlyDashboardTab } from "../lib/monthlyDashboard.mjs";

const csv = fs.readFileSync(new URL("./fixtures/kc69_sample.csv", import.meta.url), "utf8");
const rows = Papa.parse(csv, { skipEmptyLines: false }).data;
const result = parseMonthlyDashboardTab(rows);
console.log(JSON.stringify(result, null, 2));
