import fs from "node:fs";
import Papa from "papaparse";
import { rowsToObjects } from "../lib/sheets.mjs";
import { normalizePlate } from "../lib/plate.mjs";
import { parseDMY, monthKey } from "../lib/dates.mjs";

function readCsv(path) {
  return Papa.parse(fs.readFileSync(path, "utf8"), { skipEmptyLines: false }).data;
}
const gpsRows = rowsToObjects(readCsv(new URL("./fixtures/gps_activity.csv", import.meta.url)));
const kissRows = rowsToObjects(readCsv(new URL("./fixtures/kissflow_dump.csv", import.meta.url)));

const p = normalizePlate("นข-7138");
const gpsMonths = new Set();
for (const o of gpsRows) {
  if (normalizePlate(o["ชื่อรถ"]) === p) {
    const d = parseDMY(o["วันที่เริ่มบันทึก"]);
    if (d) gpsMonths.add(monthKey(d));
  }
}
console.log("GPS months present for", p, ":", [...gpsMonths].sort());

const kissMonths = new Set();
for (const o of kissRows) {
  const plateRaw = o["หมายเลขทะเบียนรถทดแทน"] || o["หมายเลขทะเบียนรถ"];
  if (normalizePlate(plateRaw) === p) {
    const d = parseDMY(o["วันที่ปฏิบัติงาน"]);
    if (d) kissMonths.add(monthKey(d));
  }
}
console.log("Kissflow months present for", p, ":", [...kissMonths].sort());

// print a couple raw sample rows to check field name spelling
console.log("\nSample gps row keys:", Object.keys(gpsRows[0]));
console.log("Sample kiss row keys:", Object.keys(kissRows[0]));

const kissRows2 = rowsToObjects(readCsv(new URL("./fixtures/kissflow_dump.csv", import.meta.url)));
let km=0, exp=0, n=0;
for (const o of kissRows2) {
  const plateRaw = o["หมายเลขทะเบียนรถทดแทน"] || o["หมายเลขทะเบียนรถ"];
  if (normalizePlate(plateRaw) === p) {
    const d = parseDMY(o["วันที่ปฏิบัติงาน"]);
    if (d && monthKey(d) === "2026-07") {
      km += parseFloat(String(o["Task Detail Table.ระยะทางที่เกิดขึ้น"]).replace(/,/g,"")) || 0;
      exp += parseFloat(String(o["ค่าใช้จ่ายที่เกิด"]).replace(/,/g,"")) || 0;
      n++;
    }
  }
}
let gpsKm=0;
for (const o of gpsRows) {
  if (normalizePlate(o["ชื่อรถ"]) === p) {
    const d = parseDMY(o["วันที่เริ่มบันทึก"]);
    if (d && monthKey(d) === "2026-07") gpsKm += parseFloat(String(o["ระยะทาง (กิโลเมตร)"]).replace(/,/g,"")) || 0;
  }
}
console.log("\nJuly for", p, "-> kissflow entries:", n, "km:", km, "expense:", exp, "| GPS km:", gpsKm, "| ratio%:", gpsKm? Math.round(km/gpsKm*100): null);
