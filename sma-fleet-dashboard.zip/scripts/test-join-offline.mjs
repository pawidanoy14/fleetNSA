// Offline sanity check of the join/aggregation logic using local CSV fixtures
// exported from the real uploaded xlsx files (no network needed — this sandbox
// can't reach Google directly, only the deployed app can).
import fs from "node:fs";
import Papa from "papaparse";
import { rowsToObjects } from "../lib/sheets.mjs";
import { normalizePlate, extractTeamNumber } from "../lib/plate.mjs";
import { parseDMY, monthKey } from "../lib/dates.mjs";

function readCsv(path) {
  const text = fs.readFileSync(path, "utf8");
  return Papa.parse(text, { skipEmptyLines: false }).data;
}

const driverRows = rowsToObjects(readCsv(new URL("./fixtures/driver_registry.csv", import.meta.url)));
const gpsRows = rowsToObjects(readCsv(new URL("./fixtures/gps_activity.csv", import.meta.url)));
const kissRows = rowsToObjects(readCsv(new URL("./fixtures/kissflow_dump.csv", import.meta.url)));

console.log("driver registry rows:", driverRows.length);
console.log("gps activity rows:", gpsRows.length);
console.log("kissflow dump rows:", kissRows.length);

const byPlate = new Map();
for (const o of driverRows) {
  const p = normalizePlate(o["ทะเบียน"]);
  if (p) byPlate.set(p, o);
}
console.log("unique normalized plates in registry:", byPlate.size);

// Aggregate GPS km per plate per month
const gpsAgg = new Map();
for (const o of gpsRows) {
  const p = normalizePlate(o["ชื่อรถ"]);
  const d = parseDMY(o["วันที่เริ่มบันทึก"]);
  if (!p || !d) continue;
  const mk = monthKey(d);
  const k = `${p}::${mk}`;
  const km = parseFloat(String(o["ระยะทาง (กิโลเมตร)"]).replace(/,/g, "")) || 0;
  gpsAgg.set(k, (gpsAgg.get(k) || 0) + km);
}

// Aggregate Kissflow km + expense per plate per month
const kissAgg = new Map();
let unmatchedTeamRows = 0;
for (const o of kissRows) {
  const d = parseDMY(o["วันที่ปฏิบัติงาน"]);
  if (!d) continue;
  const mk = monthKey(d);
  const plateRaw = o["หมายเลขทะเบียนรถทดแทน"] || o["หมายเลขทะเบียนรถ"];
  const p = normalizePlate(plateRaw);
  if (!p) { unmatchedTeamRows++; continue; }
  const k = `${p}::${mk}`;
  const dist = parseFloat(String(o["Task Detail Table.ระยะทางที่เกิดขึ้น"] ?? o["ระยะทางที่เกิดขึ้น"] ?? 0).replace(/,/g, "")) || 0;
  const exp = parseFloat(String(o["ค่าใช้จ่ายที่เกิด"] ?? 0).replace(/,/g, "")) || 0;
  const cur = kissAgg.get(k) || { km: 0, expense: 0, n: 0 };
  cur.km += dist; cur.expense += exp; cur.n += 1;
  kissAgg.set(k, cur);
}
console.log("kissflow rows with no plate at all:", unmatchedTeamRows);

// Spot-check a known vehicle: นข-7138 (SMA6 / เก๋) for March 2026
const testPlate = normalizePlate("นข-7138");
const testMonth = "2026-03";
console.log(`\nSpot check ${testPlate} (${testMonth}):`);
console.log("  driver registry entry:", byPlate.get(testPlate));
console.log("  GPS km:", gpsAgg.get(`${testPlate}::${testMonth}`));
console.log("  Kissflow km/expense:", kissAgg.get(`${testPlate}::${testMonth}`));

// How many plates in Kissflow dump fail to normalize-match anything in the registry?
const kissPlatesSeen = new Set();
for (const o of kissRows) {
  const p = normalizePlate(o["หมายเลขทะเบียนรถทดแทน"] || o["หมายเลขทะเบียนรถ"]);
  if (p) kissPlatesSeen.add(p);
}
const unmatched = [...kissPlatesSeen].filter((p) => !byPlate.has(p));
console.log("\nKissflow plates with NO match in driver registry:", unmatched.length, unmatched.slice(0, 20));
